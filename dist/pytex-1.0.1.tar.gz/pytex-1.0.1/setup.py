# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pytex']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pytex',
    'version': '1.0.1',
    'description': '',
    'long_description': '# πTex\n\nA Python-based utility for generating and compiling LaTeX documents\nprogrammatically. Ideal for automating the creation of complex LaTeX documents.\n\n## Requirements\n\n- πTex assumes that the command `pdflatex` available in your path. Please see\n  [this page](https://www.latex-project.org/get/) for instructions on how to\n  install LaTeX on your system.\n\n## Installation\n\n```bash\npip install pytex\n```\n\n## Quick Start\n\n- Minimal example:\n\n    ```python\n    from pytex import LatexDocument\n\n    # Create a new LaTeX document\n    doc = LatexDocument("my_document")\n\n    # Add content to the document\n    doc.content += r"""\n    \\section{Introduction}\n    This is an automatically generated LaTeX document.\n    """\n\n    # Compile the LaTeX document to PDF\n    doc.compile()\n    ```\n\n## Documentation\n\nDetailed documentation will be available soon.\n\n## Contributing\n\nContributions are welcome! If you\'d like to contribute, please fork the repository and use a feature branch. Pull requests are warmly welcome.\n\n## Licensing\n\nThe code in this project is licensed under [MIT license](LICENSE.md). This is a permissive license that is short and to the point. It lets people do almost anything they want with your project, like making and distributing closed source versions.\n',
    'author': 'girogio',
    'author_email': 'giorgiogrigolo03@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
